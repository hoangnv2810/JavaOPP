/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KhaiBaoLopSinhVien;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author hn281
 */
public class SinhVien {
    private String name;
    private String studentCode;
    private String className;
    private Date birthday;
    private float gpa;

    public SinhVien() {
        this.name = "";
        this.studentCode = "B20DCCN001";
        this.className = "";
        this.birthday = new Date();
        this.gpa = 0;
    }

    public SinhVien(String name, String studentCode, String className, String birthday, float gpa) throws ParseException {
        this.name = name;
        this.studentCode = studentCode;
        this.className = className;
        this.birthday = new SimpleDateFormat("dd/MM/yyyy").parse(birthday);
        this.gpa = gpa;
    }

    public String getName() {
        return name;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public String getClassName() {
        return className;
    }

    public Date getBirthday() {
        return birthday;
    }

    public float getGpa() {
        return gpa;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setBirthday(String birthday) throws ParseException {
        this.birthday = new SimpleDateFormat("dd/MM/yyyy").parse(birthday);
    }

    public void setGpa(float gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return this.studentCode + " " + this.name + " " + this.className + " "
                + new SimpleDateFormat("dd/MM/yyyy").format(birthday) + " "
                + String.format("%.2f", this.gpa);
    }



}
