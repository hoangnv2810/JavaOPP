/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KhaiBaoLopSinhVien;

import java.util.Scanner;

/**
 *
 * @author hn281
 */
public class J04006 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SinhVien st = new SinhVien();
        String name = sc.nextLine();
        String className = sc.nextLine();
        String birthday = sc.nextLine();
        float gpa = sc.nextFloat();
        st.setName(name);
        st.setBirthday(birthday.replaceAll("\\s+", ""));
        st.setGpa(gpa);
        st.setClassName(className);
        System.out.println(st);
    }
}
