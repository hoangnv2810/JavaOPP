/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KhaiBaoLopSinhVien;

/**
 *
 * @author hn281
 */
public class SinhVien {
    private String name;
    private String studentCode;
    private String className;
    private String birthday;
    private float gpa;

    public SinhVien() {
        this.name = "";
        this.studentCode = "B20DCCN001";
        this.className = "";
        this.birthday = "";
        this.gpa = 0;
    }

    public String getName() {
        return name;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public String getClassName() {
        return className;
    }

    public String getBirthday() {
        return birthday;
    }

    public float getGpa() {
        return gpa;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setGpa(float gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return this.studentCode + " " + this.name + " " + this.className + " " + this.birthday + " " + String.format("%.2f", this.gpa);
    }



}
