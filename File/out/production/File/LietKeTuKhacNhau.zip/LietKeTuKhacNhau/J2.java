package LietKeTuKhacNhau;

import java.io.IOException;

public class J2 {
    public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
}
