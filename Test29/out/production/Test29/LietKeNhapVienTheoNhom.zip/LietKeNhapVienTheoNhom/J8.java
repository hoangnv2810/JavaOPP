package LietKeNhapVienTheoNhom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<NhanVien> listNV = new ArrayList<>();
        int cntGD = 0, cntTP = 0, cntPP = 0;
        int n = Integer.parseInt(sc.nextLine());
        while(n-- > 0){
            String ma = sc.next();
            String name = sc.nextLine();
            String id = ma.substring(0,2);
            if(id.compareTo("GD") == 0 && cntGD == 0){
                NhanVien nv = new NhanVien(ma, name.trim());
                listNV.add(nv);
                cntGD++;
            } else if(id.compareTo("TP") == 0 && cntTP < 3){
                NhanVien nv = new NhanVien(ma, name.trim());
                listNV.add(nv);
                cntTP++;
            } else if(id.compareTo("PP") == 0 && cntPP < 3){
                NhanVien nv = new NhanVien(ma, name.trim());
                listNV.add(nv);
                cntPP++;
            } else if(id.compareTo("NV") == 0){
                NhanVien nv = new NhanVien(ma, name.trim());
                listNV.add(nv);
            } else {
                String tmp = "NV" + ma.substring(2);
                NhanVien nv = new NhanVien(tmp, name.trim());
                listNV.add(nv);
            }

        }
        Collections.sort(listNV);
        int q = Integer.parseInt(sc.nextLine());
//        String res = "";
        while(q-- > 0){
            String temp = sc.nextLine();
            for(NhanVien nv:listNV){
                if(temp.compareTo(nv.chuVu()) == 0){
//                    res += nv;
//                    res += '\n';
                    System.out.println(nv);
                }
            }
            if(q != 0)
                System.out.println();
//                if(q != 0){
//                    res += '\n';
//                }
        }
//        System.out.print(res);
    }
}
